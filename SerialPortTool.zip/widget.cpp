#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    this->setLayout(ui->gridLayoutTotal);
    QList<QSerialPortInfo> serialPs = QSerialPortInfo::availablePorts();
    for(QSerialPortInfo serialP : serialPs){
        qDebug() << serialP.portName();
        ui->comboBoxSerial->addItem(serialP.portName());
    }
}

Widget::~Widget()
{
    delete ui;
}
